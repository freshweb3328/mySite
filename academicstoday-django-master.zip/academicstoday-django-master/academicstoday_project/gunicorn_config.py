command = '/usr/home/django/academicstoday-django/env/bin/gunicorn'
pythonpath = '/usr/home/django/academicstoday-django/academicstoday_project'
bind = '127.0.0.1:8001'
workers = 3
